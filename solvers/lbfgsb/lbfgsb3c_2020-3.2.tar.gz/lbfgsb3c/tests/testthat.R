library(testthat)
library(lbfgsb3c)

test_check("lbfgsb3c")
